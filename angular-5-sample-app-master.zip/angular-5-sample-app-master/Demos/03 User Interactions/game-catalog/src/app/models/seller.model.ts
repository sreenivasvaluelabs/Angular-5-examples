export interface ISeller {
  id: number;
  name: string;
  price: number;
  amount: number;
  isAvailable: boolean;
}
