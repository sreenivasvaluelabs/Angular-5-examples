export interface ITax {
  id: number;
  name: string;
  amount: number;
}
